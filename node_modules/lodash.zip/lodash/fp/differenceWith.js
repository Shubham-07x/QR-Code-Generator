var convert = require('./convert'),
    func = convert('differenceWith', require('../differenceWith'));

func.placeholder = require('./placeholder');
module.exports = func;
